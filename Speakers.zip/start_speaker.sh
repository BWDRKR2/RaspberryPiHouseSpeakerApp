 gunicorn -b 192.168.1.79:5000  speakers2:app 
