#!/usr/bin/python

import sqlite3
from werkzeug.security import check_password_hash

conn = sqlite3.connect('Speakers.db')
print "Opened database successfully";

#conn.execute('''CREATE TABLE USERS
#         (ID INT PRIMARY KEY     NOT NULL,
#         User            TEXT    NOT NULL,
#         Password        INT     NOT NULL);''')
#print "Table created successfully";


#conn.execute("INSERT INTO USERS (ID,User,Password) \
#      VALUES (1, 'BWDRKR2','pbkdf2:sha1:1000$HegX5Ikp$7a51190456ff7f2c5b039804932813475b289e8b')");





#conn.commit()
print "Records created successfully";



cursor = conn.execute("SELECT id, user, password from USERS WHERE user='BWDRKR2' ")
for row in cursor:
   print "ID = ", row[0]
   print "USERS = ", row[1]
   print "PASSWORD = ", row[2]

hashpassword = row[2]

  

check_hash =  check_password_hash(hashpassword, 'Editors100')

print "Hash Passed = ", check_hash







conn.close()
