import sqlite3

conn = sqlite3.connect('Speakers.db')


conn.execute('DROP TABLE USERS;')
print "USERS Table dropped  successfully";

conn.execute('''CREATE TABLE USERS
(
User            TEXT    NOT NULL,
Password        TEXT    NOT NULL);''')
print "USERS Table created successfully";
       


