#!/usr/bin/python  
import RPi.GPIO as GPIO
import json
import falcon

class RoomOn(object):
    def on_get(self, req, resp, room_num):
	
	g = next(item for item in relays_dict['ROOMS'] if item["Room_Num"] == room_num)
	relay_1 =  g["Relay_1"]
	relay_2 =  g["Relay_2"]
        relay_1 = int(relay_1)
        relay_2 = int(relay_2)
	speaker_on(relay_1,relay_2)
        speaker_status()
        """Handles GET requests"""
        resp.status = falcon.HTTP_200  # This is the default status
        resp.body = json.dumps(relays_dict)
          
####
class RoomOff(object):
    def on_get(self, req, resp, room_num):
        #init()
        g = next(item for item in relays_dict['ROOMS'] if item["Room_Num"] == room_num)
        relay_1 =  g["Relay_1"]
        relay_2 =  g["Relay_2"]
        relay_1 = int(relay_1)
        relay_2 = int(relay_2)
        speaker_off(relay_1,relay_2)
        speaker_status()
        """Handles GET requests"""
        resp.status = falcon.HTTP_200  # This is the default status
	resp.body = json.dumps(relays_dict)
 
####
class RoomStatus(object):
    def on_get(self, req, resp):
        speaker_status()
        """Handles GET requests"""
        resp.status = falcon.HTTP_200  # This is the default status
        resp.body = json.dumps(relays_dict)

####

def speaker_on(relay_1,relay_2):
	GPIO.output(relay_1, GPIO.LOW)
  	GPIO.output(relay_2, GPIO.LOW)	
	return

def speaker_off(relay_1,relay_2):
        GPIO.output(relay_1, GPIO.HIGH)
        GPIO.output(relay_2, GPIO.HIGH)
        return

def speaker_status():
	GPIO.setmode(GPIO.BCM)
	count = 0	

        for room in relays_dict['ROOMS']:
     		relay1 = (room["Relay_1"])
         	relay2 = (room["Relay_2"])
		relay1 = int(relay1)
		relay2 = int(relay2)
		relay_status_1 = GPIO.input(relay1)
		relay_status_2 = GPIO.input(relay2)

		if relay_status_1 == 0 and relay_status_2 == 0:
			room["Status"] = "Checked"
                        count = count + 1 
		else:
                        room["Status"] = " "

 


        
        
	
        return count



with open('new.json', 'r') as f:
	relays_dict = json.load(f)


GPIO.setmode(GPIO.BCM)

for room in relays_dict['ROOMS']:
        relay1 = (room["Relay_1"]) 
	relay2 = (room["Relay_2"])
 	relay1 = int(relay1)
	relay2 = int(relay2)
	GPIO.setup(relay1, GPIO.OUT)
        GPIO.setup(relay2, GPIO.OUT)
 


app = falcon.API()

# Resources are represented by long-lived class instances
room_on = RoomOn()
room_off = RoomOff()
room_status = RoomStatus()

# things will handle all requests to the '/things' URL path
app.add_route('/room_on/{room_num}', room_on)
app.add_route('/room_off/{room_num}', room_off)
app.add_route('/room_status', room_status)
