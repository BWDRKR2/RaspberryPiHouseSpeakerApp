#!/usr/bin/python  
import RPi.GPIO as GPIO
import json
import falcon
import sqlite3
import re
from werkzeug.security import check_password_hash, generate_password_hash

class RoomOn(object):
    def on_get(self, req, resp, room_num):
	
	g = next(item for item in relays_dict['ROOMS'] if item["Room_Num"] == room_num)
	relay_1 =  g["Relay_1"]
	relay_2 =  g["Relay_2"]
        relay_1 = int(relay_1)
        relay_2 = int(relay_2)
	speaker_on(relay_1,relay_2)
        speaker_status()
        """Handles GET requests"""
        resp.status = falcon.HTTP_200  # This is the default status
        resp.body = json.dumps(relays_dict)
          
####
class RoomOff(object):
    def on_get(self, req, resp, room_num):
        #init()
        g = next(item for item in relays_dict['ROOMS'] if item["Room_Num"] == room_num)
        relay_1 =  g["Relay_1"]
        relay_2 =  g["Relay_2"]
        relay_1 = int(relay_1)
        relay_2 = int(relay_2)
        speaker_off(relay_1,relay_2)
        speaker_status()
        """Handles GET requests"""
        resp.status = falcon.HTTP_200  # This is the default status
	resp.body = json.dumps(relays_dict)
 
####
class RoomStatus(object):
    def on_get(self, req, resp):
        speaker_status()
        """Handles GET requests"""
        resp.status = falcon.HTTP_200  # This is the default status
        resp.body = json.dumps(relays_dict)

#### 
class ValidateUser(object):
    def on_get(self, req, resp, user, password):
        validation_json = val_user(user, password)
	print validation_json
        """Handles GET requests"""
        resp.status = falcon.HTTP_200  # This is the default status
        resp.body = validation_json

#### 

class CreateUser(object):
    def on_get(self, req, resp, user, password):
        create_user_json = create_a_user(user, password)
        #create_user_json = "ASAASAA"
        print create_user_json
        """Handles GET requests"""
        resp.status = falcon.HTTP_200  # This is the default status
        resp.body = create_user_json

####

class ValidatePassword(object):
    def on_get(self, req, resp, password):
        create_user_json = validate_a_password(password) 
        #create_user_json = create_a_user(user, password)
        #create_user_json = "ASAASAA"
        #create_user_json = "Testing Validate Password"
        """Handles GET requests"""
        resp.status = falcon.HTTP_200  # This is the default status
        resp.body = create_user_json


####

def speaker_on(relay_1,relay_2):
	GPIO.output(relay_1, GPIO.LOW)
  	GPIO.output(relay_2, GPIO.LOW)	
	return

def speaker_off(relay_1,relay_2):
        GPIO.output(relay_1, GPIO.HIGH)
        GPIO.output(relay_2, GPIO.HIGH)
        return

def speaker_status():
	GPIO.setmode(GPIO.BCM)
	count = 0	

        for room in relays_dict['ROOMS']:
     		relay1 = (room["Relay_1"])
         	relay2 = (room["Relay_2"])
		relay1 = int(relay1)
		relay2 = int(relay2)
		relay_status_1 = GPIO.input(relay1)
		relay_status_2 = GPIO.input(relay2)

		if relay_status_1 == 0 and relay_status_2 == 0:
			room["Status"] = "Checked"
                        count = count + 1 
		else:
                        room["Status"] = " "

 


        
        
	
        return count

###
def val_user(user,password):

	
        id = 0
	conn = sqlite3.connect('Speakers.db')
	cursor = conn.execute("SELECT rowid , user, password from USERS WHERE user = ?",(user,))
	for row in cursor:
		hashpassword = row[2]
		id = row[0]
                #id = str(id)
      
        

        if id > 0:
		check_hash =  check_password_hash(hashpassword, password)
        	if check_hash is True:
			authorized = 'Y'
		else:
			authorized = 'N'
                        print "Bad User = ",user + " " + password 
        else:
		authorized = 'N'
		print "Bad User = ",user + " " + password
        
        id = str(id)
        validation_json = '{"id":' + id + ',"Authorized":' + '"' + authorized + '"}'
        print validation_json
	return  validation_json

###
def create_a_user(user,password):

	hash_password = generate_password_hash(password)
        conn = sqlite3.connect('Speakers.db')
        #conn.execute('DROP TABLE USERS;')

	#conn.execute('''CREATE TABLE USERS
        #(
        #User            TEXT    NOT NULL,
        #Password        TEXT    NOT NULL);''')
	#print "Table created successfully";
        # cur.execute("insert into contacts (name, phone, email) values (?, ?, ?)",
           # (name, phone, email))

	conn.execute("INSERT INTO USERS ( User, Password) \
                VALUES (?, ? )",(user, hash_password))
	


	#conn.execute("INSERT INTO USERS ( User,Password) \
     		#VALUES ( 'BWDRKR2','pbkdf2:sha1:1000$HegX5Ikp$7a51190456ff7f2c5b039804932813475b289e8b')");			
	cursor = conn.execute("SELECT rowid, User, Password from USERS ")
	conn.commit()
	for row in cursor:
   		#print rowid
   		print "ID = ", row[0]
   		print "USERS = ", row[1]
   		print "PASSWORD = ", row[2]
        Sucess = "User Added"
	return Sucess
###
def validate_a_password(password):
	is_valid = True

	if (len(password)<6 or len(password)>12):
		is_valid = False

	elif not re.search("[A-Z]",password):
		is_valid = False

	elif not re.search("[a-z]",password):
		is_valid = False

	elif not re.search("[1-9]",password):
		is_valid = False

	elif not re.search("[~!@#$%^&*]",password):
		is_valid = False

	elif re.search("[\s]",password):
		is_valid = False
    


	if(is_valid):
  		error = "Password is valid"
	else:
		error = "Password lenght must be 6 to 12 charcaters, Must contain a upper case character, Must contain a lower case character, Must cointain a number, Must coantain a special character [~!@#$%^&*], Must not contaion a blank "
	return error
###


with open('new.json', 'r') as f:
	relays_dict = json.load(f)

record_index = 0
GPIO.setmode(GPIO.BCM)

for room in relays_dict['ROOMS']:
	active = (room['Active'])
        if active == "Y":
		relay1 = (room["Relay_1"]) 
		relay2 = (room["Relay_2"])
 		relay1 = int(relay1)
		relay2 = int(relay2)
		GPIO.setup(relay1, GPIO.OUT)
        	GPIO.setup(relay2, GPIO.OUT)
 	else:
		del relays_dict["ROOMS"][record_index]

	record_index = record_index +1


app = falcon.API()

# Resources are represented by long-lived class instances
room_on = RoomOn()
room_off = RoomOff()
room_status = RoomStatus()
validate_user = ValidateUser()
create_user = CreateUser()
validate_password = ValidatePassword()

# things will handle all requests to the '/things' URL path
app.add_route('/room_on/{room_num}', room_on)
app.add_route('/room_off/{room_num}', room_off)
app.add_route('/room_status', room_status)
app.add_route('/validate_user/{user}/{password}', validate_user)
app.add_route('/create_user/{user}/{password}', create_user)
app.add_route('/validate_password/{password}', validate_password)
