import RPi.GPIO as GPIO
from time import sleep

# The script as below using BCM GPIO 00..nn numbers
GPIO.setmode(GPIO.BCM)


print ("Config")
for i in range(1, 30):
        print (i)
 	GPIO.setup(i, GPIO.OUT)
  
# Turn all relays ON

print ("Turn on")
for j in range (1,30):
    print(j)
    GPIO.output(j,True)
    # Sleep for 5 seconds
    sleep(1) 
    
# Turn all relays OFF
print ("Turn off")
for k in range (1,30):
    print(k)
    GPIO.output(k, GPIO.LOW)
     
    # Sleep for 5 seconds
    sleep(1)
    
GPIO.cleanup()
