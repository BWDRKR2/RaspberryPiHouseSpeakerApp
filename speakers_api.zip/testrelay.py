#!/usr/bin/python
import RPi.GPIO as GPIO
import time
import json
import falcon

class RoomOn(object):
    def on_get(self, req, resp, room_num):
        #init()
        print 'Room = ', room_num
        relay_1 = relays_dict[room_num]['Relay_1']
        relay_2 = relays_dict[room_num]['Relay_2']
        relay_1 = int(relay_1)
        relay_2 = int(relay_2)
	speaker_on(relay_1,relay_2)
        speaker_status()
        """Handles GET requests"""
        resp.status = falcon.HTTP_200  # This is the default status
        resp.body = ('\nSpeaker On \n')
####
class RoomOff(object):
    def on_get(self, req, resp, room_num):
        #init()
        print 'Room = ', room_num
        relay_1 = relays_dict[room_num]['Relay_1']
        relay_2 = relays_dict[room_num]['Relay_2']
        relay_1 = int(relay_1)
        relay_2 = int(relay_2)
        speaker_off(relay_1,relay_2)
        speaker_status()
        """Handles GET requests"""
        resp.status = falcon.HTTP_200  # This is the default status
        resp.body = ('\nSpeaker Off \n')
####


def speaker_on(relay_1,relay_2):
        print "Speaker On"
	print "Relay = ", relay_1, " ", relay_2
	GPIO.output(relay_1, GPIO.LOW)
  	GPIO.output(relay_2, GPIO.LOW)
        #time.sleep(10);	
	return

def speaker_off(relay_1,relay_2):
        print "Speaker Off"
        print "Relay = ", relay_1, " ", relay_2
        GPIO.output(relay_1, GPIO.HIGH)
        GPIO.output(relay_2, GPIO.HIGH)
        #time.sleep(10);
        return

def speaker_status():
	GPIO.setmode(GPIO.BCM)
	pinList = [2, 3, 4, 18, 22, 23, 24, 27, 16, 20, 21, 5, 6, 13,  19, 26]
	count = 0	
        for i in pinList:
		status = GPIO.input(i)
                if status == 0:
			count = count + 1
        	print "Pin ", i, " ", status

		if i == 18 and status == 0 :
			print "Room 1 is ON"
		if i == 27 and status == 0 :
			print "Room 1 is ON"
                if i == 22 and status == 0 :
			print "Room 2 is ON"
		if i == 23 and status == 0 :
			print "Room 2 is ON"
		if i == 24 and status == 0 :
                        print "Room 3 is ON"
                if i == 3 and status == 0 :
                        print "Room 3 is ON"
		if i == 4 and status == 0 :
                        print "Room 4 is ON"
                if i == 2 and status == 0 :
                        print "Room 4 is ON"
		if i == 16 and status == 0 :
                        print "Room 5 is ON"
                if i == 20 and status == 0 :
                        print "Room 5 is ON"
		if i == 21 and status == 0 :
                        print "Room 6 is ON"
                if i == 5 and status == 0 :
                        print "Room 6 is ON"
		if i == 6 and status == 0 :
                        print "Room 7 is ON"
                if i == 13 and status == 0 :
                        print "Room 7  is ON"


	




        print "Count = ",count
        return count

##x = speaker_status()
##if x == 0  :
	##print "Need to Init"

with open('relays_1.json', 'r') as f:
	relays_dict = json.load(f)


GPIO.setmode(GPIO.BCM)

# init list with pin numbers

pinList = [2, 3, 4, 18, 22, 23, 24, 27, 16, 20, 21, 5, 6, 13,  19, 26]

# loop through pins and set mode and state to 'low'

for i in pinList: 
    	GPIO.setup(i, GPIO.OUT) 
    	#GPIO.output(i, GPIO.HIGH)
print "Init Done"
	

# time 
#init()

app = falcon.API()

# Resources are represented by long-lived class instances
room_on = RoomOn()
room_off = RoomOff()

# things will handle all requests to the '/things' URL path
app.add_route('/room_on/{room_num}', room_on)
app.add_route('/room_off/{room_num}', room_off)
